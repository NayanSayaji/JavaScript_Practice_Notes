// DOM
// document object model 
// overview
// how to use 

// a object named "document" is present in the window object
// which haves the information about the html document.. 
// all the html elements are kept inside that document object..



// we can print that object model in js as follows
// window.document bcoz document is inside of the window object 
console.log(window.document);
// but as we know window object is always there we don't need to write is always..
console.log(document);


// if we want to print it in form of js objects form the it can be using dir
console.dir(window.document);
console.dir(document);